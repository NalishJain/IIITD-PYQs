package com.IIITD_AP_KR3;

//Q8: Convert the following cmplx class into a singleton class.
// You should be able to pass the values of real and imaginary components from the main function.

public class Main8 {
    public static void main(String[] args) {

    }
}

class cmplx{
    double re;
    double im;
    cmplx(double re, double im){
        this.re=re;
        this.im=im;
    }
}