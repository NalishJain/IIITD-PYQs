package com.IIITD_AP_KR3;

//Q9: Create the list of 5 complex numbers (class=cmplx2) and print them all using an iterator in the main function.

public class Main9 {
    public static void main(String[] args) {

    }
}

class cmplx2{
    double re;
    double im;
    cmplx2(double re, double im){
        this.re=re;
        this.im=im;
    }
}